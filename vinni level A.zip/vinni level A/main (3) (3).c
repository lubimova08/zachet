/*18.	В базе данных диспетчера автоперевозок хранятся сведения об автомобилях, водителях, грузах, адресах, рейсах.
Структура входного файла in.txt (Пункт Фамилия Автомобиль Время выезда)
Мытищи	Винни-Пух МАЗ 10:00
Королев	Пятачок	ЗИЛ	10:00
Щелково	Винни-Пух МАЗ 12:00
...
Сформировать список поездок водителя Винни-Пуха, упорядочив по названиям пунктов
Структура выходного файла out.txt
Пункт	Автомобиль	Время выезда
Мытищи	МАЗ	10:00
Щелково	МАЗ	12:00
сформировать список поездок в город Щелкова упорядочив по фамилии водителя*/
#include <stdio.h> 
#include <string.h> 
#include <locale.h>
 
#define COLLEDGE_SIZE 1000 //Максимальное кол-во записей о поездках
 
// Структура для хранения информации о поездках 
typedef struct { 
    char point[50]; // Название пункта 
    char driver[50]; // Имя водителя 
    char car[50]; // Название автомобиля 
    char time[10]; // Время выезда 
} Trip; 

void print_out(Trip v[], int n) {
	FILE *out = fopen("out.txt", "w");
	for (int i = 0; i < n; i++) {
        fprintf(out, "%s %s %s %s\n", v[i].point, v[i].driver, v[i].car, v[i].time);
	}
	fclose(out);
}
//Основная функция программы
int main(void) { 
    char * locale = setlocale(LC_ALL, ""); // Установка локали (русский язык)
    Trip v[COLLEDGE_SIZE]; // Массив структур для хранения информации о поездках 
 
    // Открытие файла для чтения 
    FILE *in = fopen("in.txt", "r"); 
    int n = 0; // Инициализация счетчика записей
    Trip trip; //Создание переменной типа Trip
    int num_kolvo = 0; // кол-во поездок
    
    while (fscanf(in, "%s %s %s %s", trip.point, trip.driver, trip.car, trip.time) == 4) {
        v[n] = trip; //Добавление считанной записи в массив
        n++; //Увеличение счетчика записей
    }
    fclose(in); //Закрытие файла
    
    //сортировка выбором
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        for (int j = i + 1; j < n; j++) {
            if (strcmp(v[j].point, v[min_idx].point) < 0) {
                min_idx = j;
            }
        }
        if (min_idx != i) {
            Trip temp = v[i];
            v[i] = v[min_idx];
            v[min_idx] = temp;
        }
    }
    //проверка является ли пункт Щелково
    for (int i = 0; i < n; i++) {
        if (strcmp(v[i].point, "Щелково")==0) {
            v[num_kolvo] = v[i];
            num_kolvo++;
        }
    }
    print_out(v, num_kolvo);

    return 0; //Возврат занечения 0
}
