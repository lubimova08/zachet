/*18.	В базе данных диспетчера автоперевозок хранятся сведения об автомобилях, водителях, грузах, адресах, рейсах.
Структура входного файла in.txt (Пункт Фамилия Автомобиль Время выезда)
Мытищи	Винни-Пух МАЗ 10:00
Королев	Пятачок	ЗИЛ	10:00
Щелково	Винни-Пух МАЗ 12:00
...
Сформировать список поездок водителя Винни-Пуха, упорядочив по названиям пунктов
Структура выходного файла out.txt
Пункт	Автомобиль	Время выезда
Мытищи	МАЗ	10:00
Щелково	МАЗ	12:00
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ENTRIES 100

// Структура для хранения информации о поездках
typedef struct {
    char point[50]; // Название пункта
    char car[50];   // Название автомобиля
    char time[10];  // Время выезда
} Trip;

// Структура для хранения информации о водителях и автомобилях
typedef struct {
    char driver[50]; // Имя водителя
    char car[50];    // Название автомобиля
} DriverCarInfo;

// Функция для сравнения двух строк (названий пунктов) для использования в qsort
int compare_points(const void *a, const void *b) {
    return strcmp(((Trip *)a)->point, ((Trip *)b)->point);
}

int main() {
    Trip trips[MAX_ENTRIES];            // Массив структур для хранения информации о поездках
    DriverCarInfo driver_car[MAX_ENTRIES]; // Массив структур для хранения информации о водителях и автомобилях
    int num_trips = 0;                  // Количество записей о поездках
    int num_drivers = 0;                // Количество записей о водителях и автомобилях

    // Открытие файла для чтения с информацией о поездках
    FILE *file_trips = fopen("in.txt", "r");
    if (file_trips == NULL) { // Проверка на успешное открытие файла
        printf("Ошибка при открытии файла in.txt.\n");
        return 1;
    }

    // Считывание информации о поездках из файла
    char point[50], driver[50], car[50], time[10];
    while (fscanf(file_trips, "%s %s %s %s", point, driver, car, time) == 4) { // Считываем данные из файла в переменные
        strcpy(trips[num_trips].point, point); // Копируем данные в массив структур поездок
        strcpy(trips[num_trips].car, car);
        strcpy(trips[num_trips].time, time);
        num_trips++; // Увеличиваем счетчик записей о поездках
    }
    fclose(file_trips); // Закрываем файл

    // Открытие файла для чтения с информацией о водителях и автомобилях
    FILE *file_drivers = fopen("in2.txt", "r");
    if (file_drivers == NULL) { // Проверка на успешное открытие файла
        printf("Ошибка при открытии файла in2.txt.\n");
        return 1;
    }

    // Считывание информации о водителях и автомобилях из файла
    while (fscanf(file_drivers, "%*d %s %s", driver, car) == 2) { // Считываем данные из файла в переменные
        strcpy(driver_car[num_drivers].driver, driver); // Копируем данные в массив структур о водителях и автомобилях
        strcpy(driver_car[num_drivers].car, car);
        num_drivers++; // Увеличиваем счетчик записей о водителях и автомобилях
    }
    fclose(file_drivers); // Закрываем файл

    // Вывод и запись в файл информации о поездках водителя Винни-Пуха
    FILE *file_out = fopen("out.txt", "w");
    if (file_out == NULL) { // Проверка на успешное создание файла
        printf("Ошибка при создании файла out.txt.\n");
        return 1;
    }

    fprintf(file_out, "Пункт\tАвтомобиль\tВремя выезда\n"); // Запись заголовка в файл

    for (int i = 0; i < num_trips; i++) { // Перебираем все поездки
        for (int j = 0; j < num_drivers; j++) { // Перебираем всех водителей
            if (strcmp(trips[i].car, driver_car[j].car) == 0 && strcmp(driver_car[j].driver, "Винни-Пух") == 0) { // Если найдена поездка водителя Винни-Пуха
                fprintf(file_out, "%s\t%s\t%s\n", trips[i].point, trips[i].car, trips[i].time); // Запись информации о поездке в файл
                printf("%s\t%s\t%s\n", trips[i].point, trips[i].car, trips[i].time); // Вывод информации о поездке в консоль
                break; // Найдена соответствующая поездка, прекратить поиск водителя
            }
        }
    }
    fclose(file_out); // Закрываем файл

    return 0;
}
