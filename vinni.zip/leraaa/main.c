#include <stdio.h> 
#include <string.h> 
#include <locale.h>
#include "vinni.h" 
#define COLLEDGE_SIZE 1000
int main(void) { 
    char * locale = setlocale(LC_ALL, ""); // Установка локали (русский язык)
    Trip v[COLLEDGE_SIZE]; // Массив структур для хранения информации о поездках 
 
    // Открытие файла для чтения 
    FILE *in = fopen("in.txt", "r"); 
    int n = 0; // Инициализация счетчика записей
    Trip trip; //Создание переменной типа Trip
    int num_kolvo = 0; // кол-во поездок
    
    while (fscanf(in, "%s %s %s %s", trip.point, trip.driver, trip.car, trip.time) == 4) {
        v[n] = trip; //Добавление считанной записи в массив
        n++; //Увеличение счетчика записей
    }
    fclose(in); //Закрытие файла
    
    //сортировка выбором
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        for (int j = i + 1; j < n; j++) {
            if (strcmp(v[j].point, v[min_idx].point) < 0) {
                min_idx = j;
            }
        }
        if (min_idx != i) {
            Trip temp = v[i];
            v[i] = v[min_idx];
            v[min_idx] = temp;
        }
    }
    //проверка является ли пункт Щелково
    for (int i = 0; i < n; i++) {
        if (strcmp(v[i].point, "Щелково")==0) {
            v[num_kolvo] = v[i];
            num_kolvo++;
        }
    }
    print_out(v, num_kolvo);

    return 0; //Возврат занечения 0
}

