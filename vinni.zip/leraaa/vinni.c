#include <stdio.h> 
#include <string.h> 
#include <locale.h>
#include "vinni.h" 

void print_out(Trip v[], int n) {
 FILE *out = fopen("out.txt", "w");
 for (int i = 0; i < n; i++) {
        fprintf(out, "%s %s %s %s\n", v[i].point, v[i].driver, v[i].car, v[i].time);
 }
 fclose(out);
}

