#ifndef __vinni__
#define __vinni__
typedef struct {
    char point[50]; // Название пункта
    char driver[50]; // Имя водителя
    char car[50]; // Название автомобиля
    char time[10]; // Время выезда
} Trip;

void print_out(Trip v[], int n);
#endif
